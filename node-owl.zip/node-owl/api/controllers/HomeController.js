module.exports = {
  index: function(req, res) {
    return res.send('In Home Controller');
  }
};
