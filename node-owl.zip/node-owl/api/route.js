module.exports = {
  'get /': 'HomeController.index'
};
