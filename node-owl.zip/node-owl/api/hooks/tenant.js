module.exports = function(app) {
  return function(cb) {
    _.extend(app.config, {
      tenant: 'localhost'
    });
    app.log('in tenant hook');
    return cb();
  };
};
