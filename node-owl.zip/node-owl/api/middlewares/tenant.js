module.exports = async function(req, res, next) {
  owl.log('I am in tenant middleware');
  return next();
};
