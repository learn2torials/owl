module.exports = async function(req, res, next) {
  owl.log('I am in admin middleware');
  return next();
};
