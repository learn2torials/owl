module.exports = {
  HomeController: {
    index: ['tenant', 'admin']
  }
};
