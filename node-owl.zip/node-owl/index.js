try {
  process.chdir(__dirname);
  require('owl').boot();
} catch (e) {
  console.log(e);
}
