module.exports.view = {
  template: 'jsx',
  renderTemplateConfig: function() {
    return require('express-react-views').createEngine();
  }
};
