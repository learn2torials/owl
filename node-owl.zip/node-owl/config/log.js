module.exports.log = {
  level: 'silly'
};
